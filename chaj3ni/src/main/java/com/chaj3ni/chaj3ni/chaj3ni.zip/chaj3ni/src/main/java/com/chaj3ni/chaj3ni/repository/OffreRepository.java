package com.chaj3ni.chaj3ni.repository;

import com.chaj3ni.chaj3ni.entites.Offre;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OffreRepository extends JpaRepository<Offre, Long> {
}
