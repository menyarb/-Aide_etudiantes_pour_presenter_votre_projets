package com.chaj3ni.chaj3ni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Chaj3niApplicationTests {

	@Test
	void contextLoads() {
	}

}
